package com.example.DocLib.enums;

public enum Gender {
    MALE,FEMALE
}
