package com.example.DocLib.enums;

public enum BloodTypes {
}
