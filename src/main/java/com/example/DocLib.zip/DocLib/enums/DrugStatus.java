package com.example.DocLib.enums;

public enum DrugStatus {
    IN_USE,
    FINISHED,
    STOOPED,
    CHRONIC
}
