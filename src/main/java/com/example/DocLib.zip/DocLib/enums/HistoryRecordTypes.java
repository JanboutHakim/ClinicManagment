package com.example.DocLib.enums;

public enum HistoryRecordTypes {
    MEDICAL_HISTORY,
    SURGICAL_HISTORY,
    ALLERGIC_HISTORY
}
