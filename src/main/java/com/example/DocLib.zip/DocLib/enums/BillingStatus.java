package com.example.DocLib.enums;

public enum BillingStatus {
    PENDING,
    PAID,
    CANCELED
}
