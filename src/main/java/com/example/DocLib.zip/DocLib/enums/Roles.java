package com.example.DocLib.enums;

public enum Roles {
    PATIENT,DOCTOR,ADMIN, EMPLOYEE
}
